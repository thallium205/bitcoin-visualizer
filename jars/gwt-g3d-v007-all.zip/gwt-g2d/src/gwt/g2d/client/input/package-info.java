/**
 * Contains helper classes for managing input devices.
 */
package gwt.g2d.client.input;