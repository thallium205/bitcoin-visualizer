/**
 * Contains wrappers for multi-media classes.
 */
package gwt.g2d.client.media;