/**
 * Contains event argument objects and event handlers for the media class.
 */
package gwt.g2d.client.media.event;