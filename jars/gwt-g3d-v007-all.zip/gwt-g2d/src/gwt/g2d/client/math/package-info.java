/**
 * Contains some math-related classes.
 */
package gwt.g2d.client.math;