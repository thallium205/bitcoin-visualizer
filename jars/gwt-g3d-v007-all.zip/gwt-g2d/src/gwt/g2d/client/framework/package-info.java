/**
 * Contains an abstract application framework.
 */
package gwt.g2d.client.framework;