/**
 * Contains the framework for manipulating canvas using 2D context.
 */
package gwt.g2d.client.graphics;