/**
 * Contains the wrapper for those JavaScriptObjects related to Canvas and it
 * 2D context.
 */
package gwt.g2d.client.graphics.canvas;