/**
 * Contains a framework for building shapes.
 */
package gwt.g2d.client.graphics.shapes;