/**
 * Contains visitor classes that aids the shape building process.
 */
package gwt.g2d.client.graphics.visitor;