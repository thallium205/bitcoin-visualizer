/**
 * Contains some useful utility classes.
 */
package gwt.g2d.client.util;