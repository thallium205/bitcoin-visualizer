/**
 * Contains the ClientBundle resources for gwt-g2d.
 */
package gwt.g2d.resources.client;