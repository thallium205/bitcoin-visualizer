/**
 * Contains the generators for gwt-g2d ClientBundle resources.
 */
package gwt.g2d.resources;