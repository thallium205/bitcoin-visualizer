/**
 * Contains helper classes for managing shaders.
 */
package gwt.g3d.client.shader;