/**
 * Contains helper classes for managing the camera in a scene.
 */
package gwt.g3d.client.camera;