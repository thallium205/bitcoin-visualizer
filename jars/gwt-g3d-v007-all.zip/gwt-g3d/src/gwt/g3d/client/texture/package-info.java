/**
 * Contains helper classes for managing textures.
 */
package gwt.g3d.client.texture;