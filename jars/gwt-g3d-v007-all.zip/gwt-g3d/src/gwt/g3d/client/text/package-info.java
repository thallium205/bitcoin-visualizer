/**
 * Contains helper classes for rendering text.
 */
package gwt.g3d.client.text;