/**
 * Contains helper classes for managing a mesh.
 */
package gwt.g3d.client.mesh;