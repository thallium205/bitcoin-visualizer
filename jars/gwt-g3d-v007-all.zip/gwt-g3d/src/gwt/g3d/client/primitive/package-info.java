/**
 * Contains helper classes for creating and loading primitives.
 */
package gwt.g3d.client.primitive;