/**
 * Contains helper classes for vector math.
 */
package gwt.g3d.client.math;