/**
 * Contains wrappers WebGL arrays.
 */
package gwt.g3d.client.gl2.array;