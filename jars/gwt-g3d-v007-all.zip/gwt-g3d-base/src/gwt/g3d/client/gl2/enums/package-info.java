/**
 * Contains wrappers WebGL enums.
 */
package gwt.g3d.client.gl2.enums;