/**
 * Contains wrappers for WebGL (OpenGL ES 2.0).
 */
package gwt.g3d.client.gl2;